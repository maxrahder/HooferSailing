Ext.define('Hoofers.model.Fleet', {
    extend: 'Ext.data.Model',
    requires: ['Hoofers.model.Boat']
});