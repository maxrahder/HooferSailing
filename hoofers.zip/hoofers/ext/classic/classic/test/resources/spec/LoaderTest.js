Ext.define('Ext.spec.LoaderTest', {
    // Dummy class for when a spec needs to download a class.
});
